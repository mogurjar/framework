package POJOClasses;

public class PetSerializationDeserialization {


}
