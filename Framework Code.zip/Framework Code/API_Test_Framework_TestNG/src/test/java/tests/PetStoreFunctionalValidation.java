package tests;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;
import org.apache.http.HttpStatus;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import utils.ReadFileDetails;

public class PetStoreFunctionalValidation {
    RequestSpecification requestSpecification;
    ResponseSpecification responseSpecification;
    Response response;

    @BeforeMethod
    public void setup(){
        RestAssured.baseURI = "https://petstore.swagger.io";
        RestAssured.basePath = "/v2";
        requestSpecification = RestAssured.given();
        requestSpecification.header("Content-Type","application/json");
        requestSpecification.header("accept","application/json");
        requestSpecification.log().all();
        responseSpecification = requestSpecification.expect();
        responseSpecification.log().all();
    }
    @Test
    public void testOrderSuccessfullyPlaced(){
        String requestBody = ReadFileDetails.loadJsonFile("order_pet_request_payload");
        requestSpecification.body(requestBody);
        response = requestSpecification.post("/store/order");
        Assert.assertEquals(response.getStatusCode(), HttpStatus.SC_OK);
        JsonPath jsonPath = response.jsonPath();
        Assert.assertEquals(jsonPath.getInt("id"), 2);
        Assert.assertEquals(jsonPath.getString("shipDate"), "2022-02-02T04:15:45.783Z");
    }

    @Test
    public void testOrderIsNotSuccessfullyPlacedForInvalidBody(){
        String requestBody = ReadFileDetails.loadJsonFile("orderPet.json");
        requestSpecification.body(requestBody);
        response = requestSpecification.post("/store/order");
        Assert.assertEquals(response.getStatusCode(), HttpStatus.SC_BAD_REQUEST);
    }
}
