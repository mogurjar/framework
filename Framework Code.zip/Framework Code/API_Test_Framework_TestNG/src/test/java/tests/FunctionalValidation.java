package tests;

import POJOClasses.Category;
import POJOClasses.Pet;
import POJOClasses.Tags;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.restassured.RestAssured;
import io.restassured.config.HttpClientConfig;
import io.restassured.config.RestAssuredConfig;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.params.CoreConnectionPNames;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.List;

public class FunctionalValidation {
    Logger logger = LoggerFactory.getLogger(this.getClass());
    RequestSpecification requestSpecification;
    Response response;

    @BeforeMethod
    public void setUp() {
        RestAssured.baseURI = "https://petstore.swagger.io";
        RestAssured.basePath = "/v2";
        requestSpecification = RestAssured.given();
        requestSpecification.header("accept", "application/json");
        requestSpecification.header("Content-Type", "application/json");
        requestSpecification.log().all();
        requestSpecification.then().log().all();

        RequestConfig requestConfig = RequestConfig.custom().setConnectTimeout(1000).setConnectionRequestTimeout(1000).setSocketTimeout(1000).build();
        HttpClientConfig httpClientConfig = HttpClientConfig.httpClientConfig().httpClientFactory(() -> HttpClientBuilder.create().setDefaultRequestConfig(requestConfig).build());
        //RestAssuredConfig config = RestAssured.config().httpClient(HttpClientConfig.httpClientConfig().setParam(CoreConnectionPNames.CONNECTION_TIMEOUT, 5).setParam(CoreConnectionPNames.SO_TIMEOUT, 5));
        RestAssuredConfig config = RestAssured.config().httpClient(httpClientConfig);
    }

    @Test(enabled = false)
    public void testNewPetAddedSuccessfully() {
        String requestBody = "{\n" +
                "  \"id\": 1,\n" +
                "  \"category\": {\n" +
                "    \"id\": 1,\n" +
                "    \"name\": \"Dog\"\n" +
                "  },\n" +
                "  \"name\": \"Bruno\",\n" +
                "  \"photoUrls\": [\n" +
                "    \"https://stackoverflow.com/questions/52751877/when-launching-maven-showing-an-error-testng-xml-is-not-valid-file\"\n" +
                "  ],\n" +
                "  \"tags\": [\n" +
                "    {\n" +
                "      \"id\": 1,\n" +
                "      \"name\": \"Dog\"\n" +
                "    }\n" +
                "  ],\n" +
                "  \"status\": \"available\"\n" +
                "}";
        requestSpecification.body(requestBody);
        response = requestSpecification.post("/pet");
        response.contentType();
        logger.info("Response  Body : " + response.asString());
    }

    @Test
    public void testNewPetAddedSuccessfullyPOJO() throws JsonProcessingException {

        Pet pet = new Pet();
        pet.setId(1);

        Category category = new Category();
        category.setId(1);
        category.setName("Dog");
        pet.setCategory(category);

        pet.setName("Bruno");

        List<String> photoUrls = new ArrayList<String>();
        photoUrls.add("https://stackoverflow.com/questions/52751877/when-launching-maven-showing-an-error-testng-xml-is-not-valid-file");
        pet.setPhotoUrls(photoUrls);

        List<Tags> tags = new ArrayList<Tags>();
        Tags firstTag = new Tags();
        firstTag.setId(1);
        firstTag.setName("Dog");
        tags.add(firstTag);
        pet.setTags(tags);

        pet.setStatus("available");

        //Serialization
        ObjectMapper objectMapper = new ObjectMapper();
        String petRequestBody = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(pet);
        requestSpecification.body(petRequestBody);
        requestSpecification.post("/pet");

        logger.info("petRequestBody : " + petRequestBody);

        //Deserialization
        Pet pet2 = objectMapper.readValue(petRequestBody, Pet.class);
        logger.info("id : " + pet2.getId());
        logger.info("category name : " + pet2.getCategory().getName() + " category id " + pet2.getCategory().getId());
        logger.info("PhotoUrls : " + pet2.getPhotoUrls());
        List<Tags> tags2 = pet2.getTags();
        tags2.stream().forEach(Tags -> {
            logger.info("Tags id : " + Tags.getId());
            logger.info("Tags name : " + Tags.getName());
        });
    }
}
