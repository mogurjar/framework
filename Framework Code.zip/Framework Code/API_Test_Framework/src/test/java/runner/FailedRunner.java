package runner;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;

@CucumberOptions(features = {"@rerun/failed_scenarios.txt"},glue = "steps", monochrome = true, plugin = { "pretty",
        "html:src\\test\\resources\\reports", "rerun:rerun/failed_scenarios.txt" })
public class FailedRunner extends AbstractTestNGCucumberTests {
}
