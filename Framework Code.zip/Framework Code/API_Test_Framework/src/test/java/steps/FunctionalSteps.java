package steps;

import com.typesafe.config.Config;

import config.ConfigProvider;
import constants.EndPoint;
import constants.Index;
import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.apache.http.HttpStatus;
import org.apache.http.protocol.HTTP;
import org.testng.Assert;

import java.util.List;

public class FunctionalSteps {
	RequestSpecification requestSpecification;
	Response resposne;

	@Given("^I want to retrieve country details$")
	public void i_want_to_retrieve_country_details() throws Throwable {
		Config conf  = ConfigProvider.config().getConfig(Index.REST_COUNTRIES);
		RestAssured.baseURI = conf.getString(Index.BASE_URI);
		this.requestSpecification = RestAssured.given();
		this.requestSpecification.headers(ConfigProvider.config().getObject(Index.HEADERS).unwrapped());
		this.requestSpecification.queryParam(Index.CODES,conf.getString(Index.COUNTRY_CODE));
		this.requestSpecification.log().all().expect().log().all();
	}

	@When("^I send request with valid country code$")
	public void i_send_request_with_valid_country_code() throws Throwable {
		resposne =  this.requestSpecification.get(EndPoint.RETRIEVE_REST_COUNTRIES);
	}

	@Then("^country details should be retrieved successfully$")
	public void country_details_should_be_retrieved_successfully() throws Throwable {
		Assert.assertEquals(resposne.getStatusCode(), HttpStatus.SC_OK);

		JsonPath jsonPath = resposne.jsonPath();

	}

    @Given("^User want to use data table$")
    public void userWantToUseDataTable(DataTable dataTable) {
		List<List<String>> data = dataTable.raw();
		System.out.println(data.get(0).get(0) + " : " + data.get(1).get(0) );
		System.out.println(data.get(0).get(1) + " : " + data.get(1).get(1));
    }
}
