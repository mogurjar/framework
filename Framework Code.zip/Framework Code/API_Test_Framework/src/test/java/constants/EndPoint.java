package constants;

public class EndPoint {
	public static final String RETRIEVE_REST_COUNTRIES = "/v3.1/alpha";

}
