package constants;

public class Index {
	public static final String BASE_URI = "baseURI";
    public static final String REST_COUNTRIES = "restCountries";
    public static final String HEADERS = "headers" ;
    public static final String CODES = "codes";
    public static final String COUNTRY_CODE = "countryCode" ;
}
